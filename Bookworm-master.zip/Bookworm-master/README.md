
To run a project
# cd server
# npm run dev
# cd client
# npm start
